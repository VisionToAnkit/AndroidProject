package com.harshit.calculator

import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.DecimalFormat
import java.text.MessageFormat

class MainActivity : AppCompatActivity() {
    private lateinit var b1: Button
    private lateinit var b2: Button
    private lateinit var b3: Button
    private lateinit var b4: Button
    private lateinit var b5: Button
    private lateinit var b6: Button
    private lateinit var b7: Button
    private lateinit var b8: Button
    private lateinit var b9: Button
    private lateinit var b10: Button
    private lateinit var bPlus: Button
    private lateinit var bMinus: Button
    private lateinit var bProduct: Button
    private lateinit var bDivide: Button
    private lateinit var bDot: Button
    private lateinit var bEqual: Button
    private lateinit var bc: ImageButton
    private lateinit var bClear: Button
    private lateinit var t: TextView
    private lateinit var tr: TextView
    private var flag = 0
    private var `fun` = 0.toChar()
    private var pattern = "###,###.###"
    private var d = DecimalFormat(pattern)
    private var d1 = Double.NaN
    private var d2 = 0.0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        b1 = findViewById(R.id.num1)
        b2 = findViewById(R.id.num2)
        b3 = findViewById(R.id.num3)
        b4 = findViewById(R.id.num4)
        b5 = findViewById(R.id.num5)
        b6 = findViewById(R.id.num6)
        b7 = findViewById(R.id.num7)
        b8 = findViewById(R.id.num8)
        b9 = findViewById(R.id.num9)
        b10 = findViewById(R.id.num0)
        bPlus = findViewById(R.id.plus)
        bMinus = findViewById(R.id.minus)
        bProduct = findViewById(R.id.product)
        bDivide = findViewById(R.id.divide)
        bDot = findViewById(R.id.dot)
        bClear = findViewById(R.id.clear)
        bEqual = findViewById(R.id.equal)
        t = findViewById(R.id.textInput)
        tr = findViewById(R.id.result)
        bc = findViewById(R.id.backspace)
        b1.setOnClickListener {
            t.text = MessageFormat.format(
                "{0}1",
                t.text.toString()
            )
        }
        b2.setOnClickListener {
            t.text = MessageFormat.format(
                "{0}2",
                t.text.toString()
            )
        }
        b3.setOnClickListener {
            t.text = MessageFormat.format(
                "{0}3",
                t.text.toString()
            )
        }
        b4.setOnClickListener {
            t.text = MessageFormat.format(
                "{0}4",
                t.text.toString()
            )
        }
        b5.setOnClickListener {
            t.text = MessageFormat.format(
                "{0}5",
                t.text.toString()
            )
        }
        b6.setOnClickListener {
            t.text = MessageFormat.format(
                "{0}6",
                t.text.toString()
            )
        }
        b7.setOnClickListener {
            t.text = MessageFormat.format(
                "{0}7",
                t.text.toString()
            )
        }
        b8.setOnClickListener {
            t.text = MessageFormat.format(
                "{0}8",
                t.text.toString()
            )
        }
        b9.setOnClickListener {
            t.text = MessageFormat.format(
                "{0}9",
                t.text.toString()
            )
        }
        b10.setOnClickListener {
            t.text = MessageFormat.format(
                "{0}0",
                t.text.toString()
            )
        }
        bDot.setOnClickListener {
            t.text = MessageFormat.format(
                "{0}.",
                t.text
            )
        }
        bClear.setOnClickListener {
            tr.text = null
            t.text = null
            d1 = Double.NaN
            d2 = Double.NaN
        }
        bc.setOnClickListener {
            if (t.length() > 0) {
                val name: CharSequence = t.text.toString()
                t.text = name.subSequence(0, name.length - 1)
                d1 = Double.NaN
                d2 = Double.NaN
            } else if (t.length() == 0) {
                if (tr.length() > 0) {
                    val i = tr.text.toString()
                    tr.text = null
                    t.text = i
                    d1 = Double.NaN
                    d2 = Double.NaN
                }
            } else {
                t.text = null
                tr.text = null
                d1 = Double.NaN
                d2 = Double.NaN
            }
        }
        bProduct.setOnClickListener {
            if (t.text == null && tr.text == null) {
                t.text = null
                tr.text = null
            } else {
                try {
                    function()
                    `fun` = MUL
                    t.text = null
                    tr.text = MessageFormat.format("{0}*", d.format(d1))
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
        bPlus.setOnClickListener {
            if (t.text == null && tr.text == null) {
                t.text = null
                tr.text = null
            } else {
                try {
                    function()
                    `fun` = ADD
                    t.text = null
                    tr.text = MessageFormat.format("{0}+", d.format(d1))
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
        bMinus.setOnClickListener {
            if (t.text == null && tr.text == null) {
                t.text = null
                tr.text = null
            } else {
                try {
                    function()
                    `fun` = SUB
                    t.text = null
                    tr.text = MessageFormat.format("{0}-", d.format(d1))
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
        bDivide.setOnClickListener {
            if (t.text == null && tr.text == null) {
                t.text = null
                tr.text = null
            } else {
                try {
                    function()
                    `fun` = DIV
                    t.text = null
                    tr.text = MessageFormat.format("{0}/", d.format(d1))
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
        bEqual.setOnClickListener {
            try {
                function()
                `fun` = EQUAL
                if (flag == 0) {
                    val s = tr.text.toString()
                    tr.text = MessageFormat.format("{0}{1}", s, t.text)
                    t.text = null
                    t.text = d.format(d1)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun function() {
        if (!java.lang.Double.isNaN(d1)) {
            d2 = t.text.toString().toDouble()
            when (`fun`) {
                ADD -> {
                    d1 += d2
                    flag = 0
                }
                DIV -> try {
                    d1 /= d2
                    flag = 0
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                MUL -> {
                    d1 *= d2
                    if (d1 == -0.0) {
                        d1 = 0.0
                    }
                    flag = 0
                }
                SUB -> {
                    d1 -= d2
                    flag = 0
                }
                EQUAL -> flag++
            }
        } else {
            try {
                d1 = t.text.toString().toDouble()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    companion object {
        const val ADD = '+'
        const val MUL = '*'
        const val DIV = '/'
        const val SUB = '-'
        const val EQUAL = '='
    }
}